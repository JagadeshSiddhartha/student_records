<?php
//$conn = @mysqli_connect('localhost','pz_dev','Stp1973R','student_sid') 
$conn = @mysqli_connect('localhost','root','','student_sid') 
OR die('cannot connect to mysql  '.
mysqli_connect_error());
?>

