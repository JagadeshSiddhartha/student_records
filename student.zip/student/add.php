<html>
<head>
<title>Add Student</title>
</head>
<body>
<form action="http://localhost/student/added.php" method="GET">

</br>


          <div class = "form-group">
              <input type="text" class="form-control" name = "name" placeholder="Full Name">  </div>

         <div class = "form-group">
              <input type="email" class="form-control" name = "email" placeholder="Email">
          </div>

           <div class = "form-group">
             <input type="number" class="form-control" name = "phone" placeholder="Phone number"></div>





<table class="table table-bordered">

<div class="modal-footer">

          <input type="submit" class="btn btn-primary btn-lg" name="submit" value="Send" />
          <button type="button" class="btn btn-default btn-lg" data-dismiss="modal">Close</button>
</div>
<p>
</p>
</table>
</form>
</body>
</html>